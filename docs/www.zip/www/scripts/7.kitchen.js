/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    //styleguide documentation convert code brackets for pre tag
    function htmlEntities(str) {
      return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    var $snippets = $('.codesnippet');
    $.each($snippets, function (index, obj) {
      var $this = $(this);
      $this.html(htmlEntities($this.html()));
    });


  });
})(window, document, jQuery);

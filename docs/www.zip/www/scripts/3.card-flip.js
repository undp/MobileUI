/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    //card flip
    $('[data-hover]')
      .mouseout(function() {
        $(this).removeClass('hover').css('background-image','none');
      })
      .mouseover(function() {
        var bgImg = $(this).attr('data-map');
        $(this).addClass('hover').css('background-image', 'url(' + bgImg + ')');
      });



  });
})(window, document, jQuery);

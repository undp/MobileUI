/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    //tooltip
    $('[data-toggle="tooltip"]').tooltip();
    //$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');


  });
})(window, document, jQuery);

/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    //popover
    $('[data-toggle="popover"]').popover();


  });
})(window, document, jQuery);

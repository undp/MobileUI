/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    // for touch device in slide menu event
    $('.off-canvas [data-pop] > a').on('click', function (){
      //alert('hhhh');
      var popDiv = $(this).parent().find('.smallpop');
      $(popDiv).toggleClass('hide');
      $('.off-canvas.open').css('overflow-y','visible');
    });

    //close countries popup button
    $('a[data-popupmenu]').on('click', function(){
      //console.log(event.target.id);
      $(this).parent('#contriesPop').addClass('hide');
      $('.off-canvas.open').removeAttr('style');
    });


  });
})(window, document, jQuery);

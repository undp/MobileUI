/**
 * Created by sachink on 22/06/16.
 */
(function(window, document, $) {
  $(function() {

    // for desktop in header event
    $('header .dropdown-countries').hover(function (){
      //alert('hhhh');
      var popDiv = $(this).parent().find('.smallpop');
      $(popDiv).toggleClass('hide');
    });


    //data-popfunding
    $('[data-popfunding]').on('click touchstart',function(e) {
      var popDiv = $(this).find('.funding-popup');
      if(e.type == 'touchstart'){
        window.touchenabled = true;
        console.log('click', e.type);
        if($(popDiv).hasClass('hide')){
          $(popDiv).removeClass('hide');
          $(this).addClass('hover');
        }else{
          $(popDiv).addClass('hide');
          $(this).removeClass('hover');
        }
      }
      if(e.type == 'click'){
        if(window.touchenabled == true){
          return true;
        }
        $(popDiv).toggleClass('hide');
        $(this).toggleClass('hover');
        console.log($(popDiv).className);
      }
    });

    $('[data-popfunding]').on('mouseover',function(e) {
      if(window.touchenabled == true){
        return true;
      }
      console.log('mouseover', e.type);
      var popDiv = $(this).find('.funding-popup');
      $(popDiv).removeClass('hide');
      $(this).addClass('hover');
    });

    $('[data-popfunding]').on('mouseout',function(e) {
      if(window.touchenabled == true){
        return true;
      }
      console.log('mouseout');
      var popDiv = $(this).find('.funding-popup');
      $(popDiv).addClass('hide');
      $(this).removeClass('hover');
    });


  });
})(window, document, jQuery);
